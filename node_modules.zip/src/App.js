import Cards from './components/cards'

function App() {
  return (
    <div className="App">
      <h1 className='main-heading'>Come let's have fun!!</h1>
      <Cards />
    </div>
  );
}

export default App;
